SKIPIT — MOBILE WEB DESIGN HANDOFF
Version 1 · 13 October 2026

DELIVERED
- Interactive browser prototype for promoter, door staff and guest.
- 23 named screens across the three roles and design system (see screen-index.json for the exact inventory).
- Light and dark tokens, typography, components, statuses and full-screen verdicts.
- Exported mobile screens for every review state in both themes.
- SVG logo reconstruction, symbol, pink variant, regular 192/512px icons, maskable 192/512px icons, Apple 180px icon.
- Design source: HTML, CSS and vanilla JavaScript, with locally bundled Archivo and DM Sans fonts.

OPENING THE PROTOTYPE
Open the supplied private Site URL, or serve prototype/ with any static HTTP server (for example: python3 -m http.server 8000). A file:// preview can render but clipboard, camera, PWA and private-link routing need HTTP(S).
Use the left rail (desktop) or experience selector (mobile) to switch roles. The review panel / Screens button selects any screen and its state. The theme control cycles System, Light and Dark. System follows prefers-color-scheme.
Demo SMS code: 123456. Any syntactically valid Indian mobile number is accepted in the demo. Unknown-number states are available in the review panel.
Reset demo restores all fixtures. All names, phone numbers, attendance and payments are sample data.

CORE FLOWS
Promoter: Overview → Manage guestlist → guest actions. Mark paid directly is confirmed explicitly. Check-in admits the whole group. Guestlist filters, text search, staff addition/removal, create-event form, settings and CSV export work locally.
Door staff: Tonight → Open scanner → Scan a sample pass. This simulates an authoritative result: free/paid guests enter, due guests are held, repeat passes return Already used. The camera button shows a real camera preview only; it does not decode or validate live tickets.
Guest: Event → Choose entry → Submit → private pass. Reopening the event on the same browser shows the saved pass. Duplicate phone signup never reveals another pass. Checked-in, cancelled, event-cancelled and night-over views contain no QR.
Payment: Direct UPI is the current designed path. The sample UPI ID never triggers a money transfer. Razorpay UPI/card is a future checkout preview; success/failure states simulate outcomes.

STATE AND COPY RULES
- Green: paid, admitted, collected, regular. Yellow: due, retry, flaky. Red: cancelled, invalid, expired, already used. All have text/icon cues.
- No-show numbers and zero owed stay neutral. Pink (#FF2D7B) is exclusive to logo artwork.
- Counts are people; guestlist rows are groups. One successful check-in consumes the entire pass once.
- Women: 1–4 per group. Couple: exactly 2. Stag: per-person pricing; 20-person event capacity. These are sample entry definitions, configurable on event creation.
- Example events use 17 October 2026 with all displayed times in IST. 9 pm–3 am ends the following day.
- Empty, loading and error are reviewable where relevant. Empty create/sign-in forms are the default. Zero owed has its own neutral state.

PRODUCTION INTEGRATION REQUIRED
This is a design prototype, not an operational guestlist service. Browser storage is intentionally local and contains all demo roles. It is not authorization or a production data store.
1. SMS provider and server sessions: provision promoter accounts, maintain bouncer assignments, verify OTP expiry/rate limits, and issue secure persistent sessions. Demo route switching must be removed from the public app.
2. Server authorization: promoter owns events and payment actions; door staff can inspect/scan only assigned active lists at the same venue. Door-staff responses must exclude prices, UPI IDs, receipts and payment amounts.
3. Guest passes: create opaque high-entropy server tokens. Never return a pass by phone lookup alone. Store the caller’s own token locally for repeat visits. A token not recognized by the server is invalid. Demo tokens only resolve in the browser that created them.
4. Scan admission: online server verification, atomic compare-and-set, idempotency key, event-time/assignment checks and concurrency protection. Never admit based solely on a cached pass. Expired, cancelled or used tokens must be rejected server-side.
5. Capacity and duplicates: transactional capacity checks, unique active event+phone registrations, consistent group-size rules and server-side validation. A failed registration preserves form data and does not create a pass.
6. Payments: validate promoter UPI IDs; manual payment confirmation requires promoter authorization and an audit log. Future Razorpay amounts are set server-side; only verified signed webhooks can mark online payments paid. Handle delayed/failed transactions and refunds.
7. Live updates: server-driven counts across promoters and door staff, reconnect behavior, authoritative statuses and safe no-signal verdicts. Cache the app shell only; never use offline ticket data as admission authority.
8. Event cancellation/closing: close blocks new registrations but existing passes remain valid. Cancellation invalidates passes; paid guests require explicit refund handling. Notifications are separate from the prototype.
9. Support/privacy: supply real support contacts and privacy terms. Define retention, consent, phone normalization, export permissions and secure deletion.
10. Deployment: HTTPS on the SkipIt domain, strict headers/CSP, camera permissions, manifest and service worker. Validate on physical iPhone Safari and Android Chrome, with VoiceOver/TalkBack, large text, safe areas, and weak club connectivity before launch.

VALIDATION
Chrome browser checks covered 94 screen/state combinations in both themes, layouts at 360/390/430px, and the core interactions above. Source syntax and token contrast were checked. Text tokens meet >=4.5:1 contrast in their intended pairings. This is not a full accessibility certification or real-device Safari test.

ASSET NOTES
The vector follows the three bars + right-pointing triangle reference. The dark primary tile and inverse pink tile are supplied. The maskable symbol fits within the central 80%-diameter safe circle; solid background reaches the edges.
Fonts: Archivo and DM Sans (Google Fonts, SIL Open Font License). The prototype bundles font files to avoid runtime third-party font requests. QR encoder: qrcode-generator 1.4.4, MIT.
